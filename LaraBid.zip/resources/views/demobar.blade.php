<div class="demobar">
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <a class="btn btn-success" href="https://codecanyon.net/item/larabid-a-laravel-php-auction-platform/21221158/?ref=themeqx" target="_blank"><i class="fa fa-shopping-cart"></i> Buy Now </a>
                <a class="btn btn-default" href="https://www.themeqx.com/forums/" target="_blank"><i class="fa fa-support"></i> Get Support </a>
            </div>
        </div>
    </div>
</div>